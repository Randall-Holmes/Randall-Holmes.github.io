# define IDENT 257
# define ASSIGN 258
# define CLOSE 259
# define ESTI 260
# define EB 261
# define PN 262
# define TYPE 263
# define PROP 264
