Read Me file for Dungeons of DOS release 0.3
Sept 19, 2003

Modifications to version 0.3:  corrected a bug in setup
which might cause the death procedure to work incorrectly
(one might not return to the root of the dungeon).  In practice,
one might not notice, since the root.bat file exists anyway.

Modifications from version 0.1 include changes to setup.bat,
introduction of animate command, cleaning up the situation with
the old homer version (wormhole would not have worked with
the 0.1 help), and putting the @echo off onto wormhole.  The
layout of player command output has been improved -- most commands
now echo blank lines to make the screen output easier to read.

To start the game, click the setup.bat batch file in the
top level of the DDOS folder, and the game should start in a window.

The current dungeon is simply a test zone and rather cluttered.
It's a good idea to avoid having an active and dangerous monster
in the entrance chamber, as one re-materializes in the entrance
chamber after death, and can get into an annoying cycle of repeated
attacks.

If the game doesn't work, the first thing to check is the DDOS
environment variable -- this should point to the directory
DDOS\commands.  The game assumes that it will live in a folder
on your desktop (C:\windows\desktop\ddos\commands is the default
value of the DDOS environment variable).  If it is somewhere
else, you should edit commands\setup.bat to modify the ddos
variable.

Theoretically, one could figure out what is going on by
typing cdir at the prompt, which gives you a list of topics on
which help is available.  Type help (name of command) and you
will get an explanation of that command.  However, we
provide explanations of commands by type here.

The actual command files are found in ddos\commands, and you
can try reading them to figure out what is going on as well.

The meta-rules of this activity are that player commands are
pure batch file commands (with no associated .com or .exe files).
I do allow invocations of the command interpreter to create
subshells, but I have recently discovered a brand-new dirty
trick which (in 98 and earlier versions) makes this unnecessary.

Dungeon-master commands sometimes invoke EDIT, which is not a pure
command.

Dungeon Master Commands

This is not an exhaustive list of all the batch files to
be found in ddos\commands.  It does include all batch files
which would normally be invoked from the command line in
the current version.

SETUP.BAT:  This sets up the game.  It can take one argument, which
will be the name of the dungeon to be entered.  It also sets the
ddos environment variable.  To start the game in a DOS window,
go to the directory ddos and type

commands\setup [name of dungeon]

The dungeon name is optional; there is a default dungeon.  To
start the game in a window, click startup.bat in the DDOS folder.
Currently, startup.bat does not support the command line parameter;
you might be able to get it to go to a preferred dungeon by 
changing the properties of the icon?

CEDIT.BAT:  This is the command editor.  From anywhere in the dungeon,
you can edit any command.

cedit [name of command, without.bat]

allows you to edit first the appropriate batch file, then the 
appropriate help file, using EDIT.

TYPEEDIT.BAT:  This is the object/container type editor.

typeedit [name of type] [con]

is the syntax.  The con is optional:  this signals the system
that a .con (container or monster) file is to be edited if it is
a new file.  If the file already exists, the .con file will
be bound.  The other kind of file (for mere objects) is .obj
These files are copied to batch files and invoked when objects,
containers, or monsters are to exhibit characteristic behavior.

HELP.BAT:  Get help on commands.

help (name of command) is the syntax; help without an argument
has the same effect as help help.

CDIR.BAT:  Shows a directory of commands on which there is help.

DIG.BAT:  This is one of the two room creation commands.
The syntax is

dig [direction to go to new room] [direction to come back from new room]

The command will ask you to edit START.TXT (which will be displayed
whenever the room is entered) and EFFECTS.BAT  (which should usually
just contain rem; it is a batch file designed to cause "special effects"
in the room if any are desired).

The DIG command creates a new directory whose name is determined
by the direction in which one goes to the new room; using the
DIG command one can only create a tree structure of rooms.

WORMHOLE.BAT:  This command allows cycles in the dungeon structure.
To use it, go to the room which is to be the target of the
new route and type HOMER (which creates a file which, if executed,
will send one to that room), then go to the room where the new
route is to originate and type

wormhole [direction to target room] [direction to get back from target room]

The command is not currently "safe" (it will overwrite existing
directions!)

CREATE.BAT:  This command creates objects or containers
(an extra step is needed to create monsters -- see ASCRIBE.BAT).

create [name of type]

will create an object of the type desired unless there is already
one present.  To see a list of available types 
(first a list of object types, then a list of container/monster types)
type TYPEDIR.

ASCRIBE.BAT:  This command ascribes (or removes) properties to
containers or monsters.  

ascribe [property] [container]

or ascribe not [property] [container]

is the syntax.  A container of a monster type is not a monster
until the property ALIVE has been ascribed to it.  

ANIMATE.BAT:  This command calls ASCRIBE to ensure that a monster
is alive, not wounded and not dead.

animate [monster type]

Player Commands

Eventually I will set up the game so that there is a player mode
in which one can only use the player commands...

LOOK.BAT:  This is a user command; it is also called internally
by many other commands.  If invoked without a parameter
it shows you what room you are in,
tells you what objects are present, and activates the monsters
in the room.

If invoked with a parameter (container or monster type) it
tells you what is in the container or what the monster has,
as well as reporting properties of the container or monster.

WAYS.BAT:  This gives a list of directions in which you can go.

GO.BAT:  This allows you to move:

go [direction]

sends you to a different room.  Use WAYS to find out what
directions are available, if the text of the room doesn't tell you.

USE.BAT:  This is an all-purpose command for using an object.

use [object or container]

use [object or container] on [object or container]

is the syntax.  "use sword on orc" is a useful example.

Try "use baby" :-)

The object or container needs to be one that you have in your
possession!

GET.BAT:  pick up an object from the room (possibly from
a container) and add it to your inventory (possibly into a container).

get [object/container] from/into [object/container] from/into [object/container]

The from/into clauses are optional.  Bear in mind that there can
be no more than one object or container of any given type in
a given place (room or container), and that containers cannot
be put inside containers.

DROP.BAT:  The syntax is just like that of GET.BAT:  one
is moving an object or container from one's possession (possibly
in a container) to the room (possibly in a container).

In either GET or DROP, monsters object to being used as containers!

INVENTORY.BAT:  This gives you a list of objects and containers
in your possession (not including those inside containers),
if called without a parameter.

inventory [name of container] will tell you what you have
in the container.

NOTE WELL:  player commands sometimes invoke LOOK and so activate
monsters in the room.

ANOTHER NOTE:  When in doubt, hit return.  Player commands sometimes
pause quietly. (This is mostly no longer true in version 0.2).

FINAL NOTE:  obvious missing features are likely to appear eventually;
if you understand the system well enough to design an amusing
object or monster, send it to me...

Batch Programming Dirty Tricks:

Try to figure out how the internal file RANDOM.BAT works.  It
is a random number generator (it pauses, then executes the hundredths
digit of the time when the user hits return) using nothing
but DOS internal commands (there is a batch file which does this on the
internet, but it uses various external commands).

The internals of HOMER.BAT are a brand-new trick I found on
the internet; the old version (OLDHOMER.BAT) is similar to
RANDOM in important ways.